//
//  GuessAnimalVwCntrl.swift
//  SeaW
//
//  Created by Евгения Развадовская on 8/19/19.
//  Copyright © 2019 Евгения Развадовская. All rights reserved.
//

import UIKit

class GuessAnimalVwCntrl: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
print ("lol")
        // Do any additional setup after loading the view.
    }


    @IBOutlet weak var firstBtn: UIButton!
    @IBOutlet weak var secondBtn: UIButton!
    @IBOutlet weak var thirdBtn: UIButton!
    @IBOutlet weak var fouthBtn: UIButton!
    var answer : UIButton?
    @IBAction func showCards(_ sender: Any) {
        var cards: [UIButton] = [firstBtn, secondBtn, thirdBtn, fouthBtn]
        let randRightCard = (cards.randomElement())
        var indx : Int = 0
        answer = randRightCard
        for i in cards{
            
            if(randRightCard == i){
                cards.remove(at: indx)
            }
            else{
                indx += 1
            }
            
        }
        let randAnimal = (choosenMs.randomElement())
         var ind : Int = 0
        for i in choosenMs{
            if(randAnimal?.animalName == i.animalName){
                choosenMs.remove(at: ind)
            }
            else{
                ind += 1
            }
        }
        let name = randAnimal?.animalName
        let imgName = name! + ".png"
        randRightCard!.setBackgroundImage(UIImage(named: imgName), for : .normal)
        for i in cards {
            for j in otherAnimals{
                
                  let animalPicture = j.animalName + ".png"
                  i.setBackgroundImage(UIImage(named: animalPicture), for: .normal)
              
                
            }
              otherAnimals.removeLast()
        }
        
    }
    
    @IBOutlet weak var score: UILabel!
    @IBAction func picing(_ sender: UIButton) {
     if(   answer == sender)
     {score.text = "right answer" }
     else{score.text = "wrong"
        }
        var cards: [UIButton] = [firstBtn, secondBtn, thirdBtn, fouthBtn]
        let randRightCard = (cards.randomElement())
        var indx : Int = 0
        answer = randRightCard
        for i in cards{
            
            if(randRightCard == i){
                cards.remove(at: indx)
            }
            else{
                indx += 1
            }
            
        }
        let randAnimal = (choosenMs.randomElement())
        var ind : Int = 0
        for i in choosenMs{
            if(randAnimal?.animalName == i.animalName){
                choosenMs.remove(at: ind)
            }
            else{
                ind += 1
            }
        }
        let name = randAnimal?.animalName
        let imgName = name! + ".png"
        randRightCard!.setBackgroundImage(UIImage(named: imgName), for : .normal)
        for i in cards {
            for j in otherAnimals{
                
                let animalPicture = j.animalName + ".png"
                i.setBackgroundImage(UIImage(named: animalPicture), for: .normal)
                
                
            }
            otherAnimals.removeLast()
        }
    }
    



}
