//
//  GuessAnimalVwCntrl.swift
//  SeaW
//
//  Created by Евгения Развадовская on 8/19/19.
//  Copyright © 2019 Евгения Развадовская. All rights reserved.
//

import UIKit

class GuessAnimalVwCntrl: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        loadCards()
    }


    @IBOutlet weak var finishLbl: UILabel!
    @IBOutlet weak var firstBtn: UIButton!
    @IBOutlet weak var secondBtn: UIButton!
    @IBOutlet weak var thirdBtn: UIButton!
    @IBOutlet weak var fouthBtn: UIButton!
    var answer : UIButton?
    @IBOutlet weak var score: UILabel!
    @IBAction func picing(_ sender: UIButton) {
        var rightAnswer: Int = 0
        var wrongAnswer: Int = 0
     if(   answer == sender)
     {
        rightAnswer += 1
       
        score.text = "\(rightAnswer):\(wrongAnswer)"
        }
     else{
        wrongAnswer += 1
        
        score.text = "\(rightAnswer):\(wrongAnswer)"
        }
loadCards()
    }
    
    
    func loadCards(){
        if (!choosenMs.isEmpty){
        var cards: [UIButton] = [firstBtn, secondBtn, thirdBtn, fouthBtn]
        let randRightCard = (cards.randomElement())
        var indx : Int = 0
        answer = randRightCard
        for i in cards{
            
            if(randRightCard == i){
                cards.remove(at: indx)
            }
            else{
                indx += 1
            }
            
        }
        let randAnimal = (choosenMs.randomElement())
        var ind : Int = 0
        for i in choosenMs{
            if(randAnimal?.animalName == i.animalName){
                choosenMs.remove(at: ind)
            }
            else{
                ind += 1
            }
        }
        let name = randAnimal?.animalName
        let imgName = name! + ".png"
        randRightCard!.setBackgroundImage(UIImage(named: imgName), for : .normal)
        for i in cards {
            for j in otherAnimals{
                
                let animalPicture = j.animalName + ".png"
                i.setBackgroundImage(UIImage(named: animalPicture), for: .normal)
            }
            otherAnimals.removeLast()
        }
    }
        else {
         finishLbl.isHidden = false
        }

    }

}
