//
//  AnimalCl.swift
//  SeaW
//
//  Created by Евгения Развадовская on 8/18/19.
//  Copyright © 2019 Евгения Развадовская. All rights reserved.
//

import Foundation

var choosenMs = [Animal]()
var otherAnimals = [Animal]()
class Animal {
    
    var animalName: String
    var animalExist: Bool
    init(animalName: String, animalExist: Bool){
        self.animalName = animalName
        self.animalExist = animalExist
    }

}
