//
//  ViewController.swift
//  SeaW
//
//  Created by Евгения Развадовская on 8/18/19.
//  Copyright © 2019 Евгения Развадовская. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


    //@IBOutlet weak var zhmyakLbl: UILabel!
    //@IBOutlet weak var meLbl: UILabel!
    @IBOutlet weak var blueBG: UIView!
    @IBOutlet weak var chooseBtn: UIButton!
    @IBOutlet weak var seaImg: UIImageView!
    @IBOutlet weak var startLbl: UILabel!
    @IBOutlet weak var startBtn: UIButton!
    //@IBOutlet weak var boxView: UIImageView!
    //@IBOutlet weak var animalView: UIImageView!
    //@IBOutlet weak var animalName: UILabel!
    @IBAction func startViewChangeBtn(_ sender: Any) {
         print ("help")
        let yPosition = seaImg.frame.origin.y + 430
        let xPosition = seaImg.frame.origin.x
        let height = seaImg.frame.height + 600
        let width = seaImg.frame.width
        ////
        let yPositionBtn = chooseBtn.frame.origin.y - 540
        let xPositionBtn = chooseBtn.frame.origin.x
        let heightBtn = chooseBtn.frame.height
        let widthBtn = chooseBtn.frame.width
        startLbl.isHidden = true
        startBtn.isHidden = true
      UIView.animate(withDuration: 1, animations: {self.seaImg.frame = CGRect(x: xPosition, y: yPosition, width: width, height: height)})
        {(fineshed) in
            self.seaImg.isHidden = true
            self.blueBG.isHidden = false
            self.chooseBtn.isHidden = false
           // self.boxView.isHidden = false
           // self.animalView.isHidden = false
            //self.animalName.isHidden = false
           // self.meLbl.isHidden = false
            //self.zhmyakLbl.isHidden = false
            UIView.animate(withDuration: 1, animations: {self.chooseBtn.frame = CGRect(x: xPositionBtn, y: yPositionBtn, width: widthBtn, height: heightBtn)})
        }
    }
    

    @IBAction func randomAnimal(_ sender: Any) {
        
        let secondViewController:RandomAnimalCntrl = RandomAnimalCntrl(nibName: nil, bundle: nil)
        
        self.present(secondViewController, animated: false, completion: nil)
    }
    
    
    
}

