# Wave
 Ocean is shaking. It is my intepritation of the popular children's game. easy rules: 
 1) every person (except the lead) should pic animal character in app 
 2) a lead start a game? when every one took the pose of the animal
 3) if animal on pic exists (in app lea see 4 cards, only one exist
 4) losing the man did not guess
