//
//  RandomAnimalCntrl.swift
//  SeaW
//
//  Created by Евгения Развадовская on 8/18/19.
//  Copyright © 2019 Евгения Развадовская. All rights reserved.
//

import UIKit

var allAnimals: [String] = [ "dog", "cat", "cow", "snake", "deer", "pig",   "fish", "jellyfish", "crab"]



class RandomAnimalCntrl: UIViewController {
    @IBOutlet weak var animalPic: UIImageView!
    @IBOutlet weak var nameLbl: UILabel!
    @IBOutlet weak var randBtn: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    
    @IBAction func randomAnimal(_ sender: Any){
        let randAnimalName = (allAnimals.randomElement())
        var indx: Int = 0
        for i in allAnimals{
            if randAnimalName == i {
                allAnimals.remove(at: indx)
            }
            else{
                indx += 1
            }
        }
        let anim: Animal = Animal(animalName: randAnimalName!, animalExist: true)
        choosenMs.append(anim)
        nameLbl.text = randAnimalName
        let png : String = ".png"
        let imageName = randAnimalName! + png
        animalPic.image = UIImage(named:imageName)
        self.view.addSubview(animalPic)
    }
    

    @IBAction func otherAnimalAdd(_ sender: Any) {
        for i in allAnimals{
            let animal: Animal = Animal(animalName: i, animalExist: false)
            otherAnimals.append(animal)
        }
        print("lola")
    }
    
}
